package com.movies_rating;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviesRatingApplicationTests {

	@Test
	void contextLoads() {
	}

}
