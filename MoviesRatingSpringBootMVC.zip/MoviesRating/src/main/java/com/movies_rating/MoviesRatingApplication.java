package com.movies_rating;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoviesRatingApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoviesRatingApplication.class, args);
	}

}
